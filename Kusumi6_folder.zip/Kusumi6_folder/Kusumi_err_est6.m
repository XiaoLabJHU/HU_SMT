% Because I cannot figure out how to do bootstrapping using the "normal"
% method of the MATLAB function bootstrp, here is my own code on how to do
% that. This will take the trajectories and take a subset of the
% trajectories, calculate the MSD and then fit it to the Kusumi equation.
% These values will be retained and the error in the fit will be
% calculated.

function [std_L, std_D, Coeffs] = Kusumi_err_est6(traj, t, n, dd, iter)

Coeffs = zeros(iter, 3);


for ii = 1:iter
    s_n = traj(randperm(length(traj), length(traj)-1));
    % calculate all displacements
    d_all = [];
    D_all = [];
    
    % calculates ALL displacements
    for i = 1: length(s_n)
        if length(s_n(i).frames) > 1
            d = TrajDispl_weighted(s_n(i).coordinates(:, dd), s_n(i).frames, 100);
            d_all(end+1:end+size(d, 1), :) = d;
        end
    end
    
    time_lags = unique(d_all(:, 1));
    
    % finds the mean displacement squared from above displacements
    for i = 1:n
        ind=find(d_all(:, 1) == time_lags(i));
        D_all(i, 1) = t * time_lags(i); % converts to real time lag
        D_all(i, 2) = mean(d_all(ind, 2)); %MSD in x-direction for timelag i
        D_all(i, 3) = std(d_all(ind, 2))/sqrt(length(ind)); %sem in x-direction for timelag i
        D_all(i, 4) = std(d_all(ind, 2));
        D_all(i, 5) = length(d_all(ind, 2));
    end
    
    % estimate initial conditions from the data
    coefficients = [];
    sApprox = [];
    LApprox = [];
    cguess = 0.003;
    
    coefficients = polyfit(D_all(1:5, 1), D_all(1:5, 2), 1); 
    sApprox = sqrt(coefficients(1)); %starting value for sx
    LApprox = sqrt(D_all(end,2)); %starting value for Lx
    
    % calculate the best fit to get Kusumi equation parameters

    %guess = [LApprox, sApprox, cguess];
    guess2 = [rand, rand, rand];
    [Coeffs(ii, :), g, exitflag] = fminsearch(@(x) kusumi_lsm_wcost(x, D_all), guess2,...
        optimset('MaxIter',10000,'TolX',5e-7,'TolFun',5e-7,'MaxFunEvals',100000));


end

std_L = std(Coeffs(:,1));
std_D = std(Coeffs(:,2));

end