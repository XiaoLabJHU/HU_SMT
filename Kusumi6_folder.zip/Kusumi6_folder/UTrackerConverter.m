function s=UTrackerConverter(Struc)

for i=1:length(Struc.TracksROI)
    s(i).frames=Struc.TracksROI(i).Coordinates(:,1);
    s(i).coordinates(:,1)=Struc.TracksROI(i).Coordinates(:,2);
    s(i).coordinates(:,2)=Struc.TracksROI(i).Coordinates(:,3);
    s(i).intensity=Struc.TracksROI(i).Coordinates(:,4);
    s(i).mol_id=i;
    if isfield(Struc,'Source')
         s(i).data_id = Struc.Source{i};
    elseif isfield(Struc, 'data_id')
         s(i).data_id=Struc.data_id{i};
    else
        s(i).data_id = [];
    end
end

end