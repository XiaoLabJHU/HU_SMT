function g = kusumi_lsm_wcost(Coeff, dataset)
% test function for Least Squares minimization
% Coeff(1) = Lx
% Coeff(2) = sx
L=Coeff(1);
c=Coeff(3);
w = dataset(:, 5);

g=0;
for i=1:length(dataset)
    t=dataset(i,1);
    F=L^2/6-16*L^2/pi^4*ApproxSum(Coeff, t)+c;
    squared_diff=w(i)*(dataset(i,2)-F)^2;
    g=g+squared_diff;
end

end
    


