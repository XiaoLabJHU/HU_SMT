% Updated Kusumi code, written KB 2-26-2018
% 
% INPUTS:
%     traj = your trajectory structure in either Octane or UTrack format
%     t = time between each frame
%     n = how many timelags you want to calculate out to
%     pixSize = pixel size in nanometers
%     opt = string that describes which dimension you want to calculate the
%     MSD over
%           'x' - only the x-direction
%           'y' - only the y-direction
%           'z' - only the z-direction
%           'xy' - the x-y plane
%           'yz' - the y-z plane
%           'xz' - the x-z plane
%           'xyz' - the xyz plane
%
% Code calculates the MSD and fits that to the "Kusumi equation" which is
% the equation of the MSD under the assumption that your molecule of
% interest is diffusing within a boundary of length L. Calculates the
% boundary length L and the diffusion coefficient.
%
%  EQUATION:   MSD(t) = L^6 + 16*L^2/pi^4 * sum(from i = 1 to inf) 1/i^4 *
%  exp(-0.5*i^2*pi^2*s^2/L^2*t)
% Reference: A. Kusumi, Y. Sako, M. Yamamoto,
% Confined lateral diffusion of membrane receptors as studied by single particle tracking (nanovid microscopy). Effects of calcium-induced differentiation in cultured epithelial cells,
% Biophysical Journal, Volume 65, Issue 5, 1993, Pages 2021-2040, ISSN 0006-3495, https://doi.org/10.1016/S0006-3495(93)81253-0.
%
% *** The way the MSD is calculated uses all trajectories regardless of
% length, and DOES weight MSD by trajectory
%
% OUTPUTS:
%     results: structure that contains the following
%         results.D_all = the MSD matrix
%         results.L = confinement length (represents the diameter if you
%         select 'xy')
%         results.std_L = ESTIMATED standard deviation of L
%         results.sigma = related to the Diffusion coefficient
%         results.D = diffusion coefficient calculated from data
%         results.std_D = ESTIMATED standard deviation of D
%         results.dist_coeffs = the values from the pseudo-bootstrapping
%         results.xx = the time values for the resulting fit
%         results.F =  the y values for the resulting fit
%         results.c = the constant at timepoint 0; related to your
%         resolution
%         results.resid = residuals of fit


function results = Kusumi6(traj, t, n, pixSize, opt)

if isfield(traj, 'TracksROI')
    s = UTrackerConverter(traj);
elseif isfield(traj, 'frames')
    s = traj;
else
    error('File format not supported, use Octane or UTrack format only')
    return;
end

dd = 1;
switch opt
    case 'x'
        dd = 1;
    case 'y'
        dd = 2;
    case 'z'
        dd = 3;
    case 'xy'
        dd = 1:2;
    case 'xz'
        dd = [1, 3];
    case 'yz'
        dd = 2:3;
    case 'xyz'
        dd = 1:3;
    otherwise
        disp('Invalid dimension; using default dimension "x"')
end

% calculate all displacements
d_all = [];
D_all = [];

% calculates ALL displacements
for i = 1: length(s)
    if length(s(i).frames) > 1
        d = TrajDispl_weighted(s(i).coordinates(:, dd), s(i).frames, pixSize);
        d_all(end+1:end+size(d, 1), :) = d;
    end
end

time_lags = unique(d_all(:, 1));

% finds the mean displacement squared from above displacements
for i = 1:n
    ind=find(d_all(:, 1) == time_lags(i));
    D_all(i, 1) = t * time_lags(i); % converts to real time lag
    D_all(i, 2) = mean(d_all(ind, 2)); %MSD in x-direction for timelag i
    D_all(i, 3) = std(d_all(ind, 2))/sqrt(length(ind)); %sem in x-direction for timelag i
    D_all(i, 4) = std(d_all(ind, 2)); % std
    D_all(i, 5) = length(d_all(ind, 2)); % num points
end

coefficients = polyfit(D_all(1:5, 1), D_all(1:5, 2), 1);
sApprox = sqrt(coefficients(1)); %starting value for sx
LApprox = sqrt(D_all(end,2)); %starting value for Lx
cguess = 0.0035;

% calculate the best fit to get Kusumi equation parameters

guess = [LApprox, sApprox, cguess];
%guess2 = [rand, rand, rand];
[Coeff, g, exitflag] = fminsearch(@(x) kusumi_lsm_wcost(x, D_all), guess,...
    optimset('MaxIter',10000,'TolX',5e-7,'TolFun',5e-7,'MaxFunEvals',100000));

[std_L, std_D, dist_coeffs] = Kusumi_err_est6(s, t, n, dd, 100);

L = Coeff(1);
sigma = Coeff(2);
D = (Coeff(2)^2)/2;
c = Coeff(3);

xx = linspace(0,(n+1)*t, 100);
F=zeros(length(xx),1);

for i = 1:length(xx)
    F(i) = L^2/6-16*L^2/pi^4*ApproxSum(Coeff, xx(i))+c;
end

resid = zeros(length(D_all(:,1)), 1);
for i = 1:length(D_all(:, 1))
    ff = L^2/6-16*L^2/pi^4*ApproxSum(Coeff, D_all(i, 1))+c;
    resid(i) = D_all(i, 2) - ff;
end

%save results
results.D_all = D_all;
results.d_all = d_all;
results.L = L;
results.std_L = std_L;
results.sigma = sigma;
results.D = D;
results.std_D = std_D^2/2;
results.dist_coeffs = dist_coeffs;
results.xx = xx;
results.F = F;
results.c = c;
results.resid = resid;

figure
hold on
errorbar(D_all(1:n, 1), D_all(1:n, 2), D_all(1:n, 3), 'ob')
plot(xx, F, '--r')
axis([0 (n+1)*t 0 max(D_all(:,2))+2*max(D_all(:,3))])


end
